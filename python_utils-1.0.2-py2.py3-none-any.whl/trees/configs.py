from enum import Enum


class TraversalOrder(Enum):
	PREORDER = 1
	INORDER = 2
	POSTORDER = 3


class TraversalMode(Enum):
	RECURSIVE = 1
	ITERATIVE = 2
