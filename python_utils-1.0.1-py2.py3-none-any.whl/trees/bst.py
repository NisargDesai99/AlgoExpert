from enum import Enum


class Node:
	def __init__(self, value):
		self.value = value
		self.left = None
		self.right = None

	def __repr__(self):
		return str(self.value)

	def __str__(self):
		return str(self.value)

	# TODO: what is the difference between __cmp__ and __eq__?; Maybe __cmp__ is used for 'is' comparison
	# def __cmp__(self, other):
	# 	return self.value == other.value

	def __eq__(self, other):
		return self.value == other.value

	def __ne__(self, other):
		return self.value != other.value

	def __lt__(self, other):
		return self.value < other.value

	def __le__(self, other):
		return self.value <= other.value

	def __gt__(self, other):
		return self.value > other.value

	def __ge__(self, other):
		return self.value >= other.value


class TraversalOrder(Enum):
	PREORDER = 1
	INORDER = 2
	POSTORDER = 3


class TraversalMode(Enum):
	RECURSIVE = 1
	ITERATIVE = 2


# TODO: implement exception handling and logging
class BST:
	def __init__(self, *args, **kwargs):
		self.root: Node = \
			kwargs['root'] if 'root' in kwargs else None
		self.traversal_mode: TraversalMode = \
			kwargs['traversal_mode'] if 'traversal_mode' in kwargs else TraversalMode.ITERATIVE								# added traversal modes to learn both for insertion

	def insert(self, value, traversal_mode: TraversalMode):
		mode = self.traversal_mode if traversal_mode is None else traversal_mode
		if mode == TraversalMode.ITERATIVE:
			self.__insert_iterative(self.root, Node(value))
		elif mode == TraversalMode.RECURSIVE:
			self.root = self.__insert_recursive(self.root, Node(value))

	def __insert_recursive(self, root: Node, new_node: Node):
		curr_node = root
		if curr_node is None:
			return new_node
		if new_node < curr_node:
			curr_node.left = self.__insert_recursive(curr_node.left, new_node)
		elif new_node >= curr_node:
			curr_node.right = self.__insert_recursive(curr_node.right, new_node)
		else:
			return curr_node
		return curr_node

	def __insert_iterative(self, root: Node, new_node: Node):
		curr_node = root
		parent = None
		while curr_node is not None:
			parent = curr_node
			if new_node < curr_node:
				curr_node = curr_node.left
			elif new_node >= curr_node:
				curr_node = curr_node.right
		if parent is None:		# tree root had no children; nothing has been inserted yet
			self.root = new_node
		elif new_node < parent:
			parent.left = new_node
		elif new_node >= parent:
			parent.right = new_node

	def build_from_list(self, values):
		for item in values:
			self.insert(item, TraversalMode.ITERATIVE)

	def get_as_list(self, order: TraversalOrder = TraversalOrder.PREORDER):
		if order == TraversalOrder.PREORDER:
			return BST.__get_as_preorder_list(self.root)
		elif order == TraversalOrder.INORDER:
			print('INORDER traversal not implemented')
			return []
		elif order == TraversalOrder.POSTORDER:
			print('POSTORDER traversal not implemented')
			return []

	def search(self, value):
		curr_node = self.root
		search_node = Node(value)
		while curr_node is not None:
			if search_node < curr_node:
				curr_node = curr_node.left
			elif search_node > curr_node:
				curr_node = curr_node.right
			elif search_node == curr_node:
				return curr_node

	def show(self, order: TraversalOrder = TraversalOrder.PREORDER):
		if self.root is None:
			print('Tree is empty...')
			return
		if order == TraversalOrder.PREORDER:
			print(', '.join(BST.__get_as_preorder_list(self.root)))
		elif order == TraversalOrder.INORDER:
			print('INORDER traversal not implemented')
		elif order == TraversalOrder.POSTORDER:
			print('POSTORDER traversal not implemented')

	@staticmethod
	def __get_as_preorder_list(curr_node):
		tree_stack = [curr_node]
		preorder_list = []
		while len(tree_stack) != 0:
			curr_node = tree_stack.pop()
			preorder_list.append(str(curr_node))
			if curr_node.right is not None:
				tree_stack.append(curr_node.right)
			if curr_node.left is not None:
				tree_stack.append(curr_node.left)
		return preorder_list

	@staticmethod
	def __get_as_inorder_list(curr_node):
		tree_stack = [curr_node]
		preorder_list = []
		# while len(tree_stack) != 0:
			# preorder_list.append(str(curr_node))
			# curr_node = tree_stack.pop()
			# if curr_node.right is not None:
			# 	tree_stack.append(curr_node.right)
			# if curr_node.left is not None:
			# 	tree_stack.append(curr_node.left)
		return preorder_list
